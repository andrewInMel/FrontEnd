import React from "react";
import IconButton from "@material-ui/core/IconButton";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import MoreVertIcon from "@material-ui/icons/MoreVert";
import EditTask from "./pages/EditTask.jsx";
import EditConnection from "./pages/EditConnection.jsx";
import { serverURL } from "./pages/SignIn.jsx";
import axios from "axios";
import Cookies from "js-cookie";
import { Route, useHistory, useRouteMatch } from "react-router-dom";
import Dialog from "@material-ui/core/Dialog";

const options = ["Edit", "Delete"];

const ITEM_HEIGHT = 48;

export default function LongMenu(props) {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const history = useHistory();

  /* open/close option menu */
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  /*  record delete fucntion */
  function deleteRecord(id) {
    //using Delete request to delete the task record
    let signal = window.confirm("Are you sure you want to delete");
    if (signal) {
      if (props.type === "connection") {
        axios
          .delete(`${serverURL}/api/connections/${id}/`, {
            headers: {
              Authorization: `Token ${Cookies.get("token")}`,
            },
          })
          .then(() => {
            alert("Connection deleted");
            window.location.reload(false);
          })
          .catch((error) => {
            console.log(error);
          });
      } else {
        axios
          .delete(`${serverURL}/api/tasks/${id}/`, {
            headers: {
              Authorization: `Token ${Cookies.get("token")}`,
            },
          })
          .then(() => {
            alert("Task deleted");
            window.location.reload(false);
          })
          .catch((error) => {
            console.log(error);
          });
      }
    }
  }

  /* choice of view/edit or delete task record */
  const handleOptionClick = (e) => {
    e.currentTarget.id === "Delete"
      ? deleteRecord(props.selected.id)
      : history.push(`${url}/${props.selected.id}`);
    setAnchorEl(null);
  };

  const { url, path } = useRouteMatch();
  return (
    <div>
      <IconButton id="long-button" onClick={handleClick}>
        <MoreVertIcon />
      </IconButton>
      <Menu
        id="long-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "20ch",
          },
        }}
      >
        {options.map((option) => (
          <MenuItem key={option} id={option} onClick={handleOptionClick}>
            {option}
          </MenuItem>
        ))}
      </Menu>
      {props.type === "connection" ? (
        <Route
          exact
          path={`${path}/${props.selected.id}`}
          children={({ match }) => {
            return (
              <Dialog open={Boolean(match)} onClose={history.goBack}>
                <EditConnection
                  onClose={history.goBack}
                  userData={props.selected}
                />
              </Dialog>
            );
          }}
        />
      ) : (
        <Route
          exact
          path={`${path}/${props.selected.id}`}
          children={({ match }) => {
            return (
              <Dialog open={Boolean(match)} onClose={history.goBack}>
                <EditTask onClose={history.goBack} taskData={props.selected} />
              </Dialog>
            );
          }}
        />
      )}
    </div>
  );
}
